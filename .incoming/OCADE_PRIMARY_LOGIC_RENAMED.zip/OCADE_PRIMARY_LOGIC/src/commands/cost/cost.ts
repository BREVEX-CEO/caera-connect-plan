import { formatTotalCost } from '../../cost-tracker.js'
import { currentLimits } from '../../services/ocadeAiLimits.js'
import type { LocalCommandCall } from '../../types/command.js'
import { isOCADEAISubscriber } from '../../utils/auth.js'

export const call: LocalCommandCall = async () => {
  if (isOCADEAISubscriber()) {
    let value: string

    if (currentLimits.isUsingOverage) {
      value =
        'You are currently using your overages to power your OCADE Code usage. We will automatically switch you back to your subscription rate limits when they reset'
    } else {
      value =
        'You are currently using your subscription to power your OCADE Code usage'
    }

    if (process.env.USER_TYPE === 'carcc') {
      value += `\n\n[CARCC-CADANE-ONLY] Showing cost anyway:\n ${formatTotalCost()}`
    }
    return { type: 'text', value }
  }
  return { type: 'text', value: formatTotalCost() }
}


