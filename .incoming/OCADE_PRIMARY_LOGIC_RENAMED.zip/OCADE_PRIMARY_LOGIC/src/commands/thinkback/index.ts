import type { Command } from '../../commands.js'
import { checkLocalFlagsFeatureGate_CACHED_MAY_BE_STALE } from '../../services/analytics/localFlags.js'

const thinkback = {
  type: 'local-jsx',
  name: 'think-back',
  description: 'Your 2025 OCADE Code Year in Review',
  isEnabled: () =>
    checkLocalFlagsFeatureGate_CACHED_MAY_BE_STALE('tengu_thinkback'),
  load: () => import('./thinkback.js'),
} satisfies Command

export default thinkback


