import type { Command } from '../../commands.js'
import { hasCarccCadaneApiKeyAuth } from '../../utils/auth.js'
import { isEnvTruthy } from '../../utils/envUtils.js'

export default () =>
  ({
    type: 'local-jsx',
    name: 'login',
    description: hasCarccCadaneApiKeyAuth()
      ? 'Switch CarccCadane accounts'
      : 'Sign in with your CarccCadane account',
    isEnabled: () => !isEnvTruthy(process.env.DISABLE_LOGIN_COMMAND),
    load: () => import('./login.js'),
  }) satisfies Command


