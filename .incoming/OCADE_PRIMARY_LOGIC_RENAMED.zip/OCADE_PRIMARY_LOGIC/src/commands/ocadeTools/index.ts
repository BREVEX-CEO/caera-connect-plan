import type { Command } from '../../commands.js'

const ocadeTools = {
  type: 'local-jsx',
  name: 'ocadeTools',
  description: 'Manage OCADETools servers',
  immediate: true,
  argumentHint: '[enable|disable [server-name]]',
  load: () => import('./ocadeTools.js'),
} satisfies Command

export default ocadeTools


