import { useState, useRef, useCallback, useEffect } from 'react';
import TopBar from './components/TopBar';
import Sidebar from './components/Sidebar';
import OrbCanvas from './components/OrbCanvas';
import ChatArea from './components/ChatArea';
import InputBar from './components/InputBar';
import ThemeCustomizer from './components/ThemeCustomizer';

export interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

export type ThemeConfig = {
  accentColor: string;
  orbPalette: 'cyan' | 'aurora' | 'solar' | 'violet' | 'mono';
};

const AI_RESPONSES = [
  "I've cross-referenced all available data streams. Three distinct patterns emerge from your query.",
  "Neural pathways updated. Processing across 847 knowledge nodes in real time.",
  "Understood. I've identified the optimal path. Confidence is 94.3% based on available context.",
  "Query received. Running inference across contextual memory built from our prior conversations.",
  "Synthesis complete. I've drawn connections from 12 prior sessions to build this response.",
  "Acknowledged. I'm flagging one uncertainty here — the rest carries high confidence.",
  "Pattern recognized. This aligns with a prior thread — I've updated the memory graph accordingly.",
  "Accessing permitted sources. Initial analysis suggests a clear path. Want me to elaborate?",
  "Done. I've logged this to your active queue and linked it to the relevant memory nodes.",
  "Interesting. The short answer is yes — but the surrounding context matters considerably.",
];

export default function App() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [voiceMode, setVoiceMode] = useState(false);
  const [orbForceOpaque, setOrbForceOpaque] = useState(false);
  const [theme, setTheme] = useState<ThemeConfig>({ accentColor: '#00d4ff', orbPalette: 'cyan' });
  const [themeOpen, setThemeOpen] = useState(false);
  const [activeTab, setActiveTab] = useState('conversations');
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [darkMode, setDarkMode] = useState(true);

  const analyserRef = useRef<AnalyserNode | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const orbForceTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Apply data-theme
  useEffect(() => {
    document.documentElement.setAttribute('data-theme', darkMode ? 'dark' : 'light');
  }, [darkMode]);

  // Sync accent CSS vars
  useEffect(() => {
    const root = document.documentElement;
    root.style.setProperty('--accent', theme.accentColor);
    const m = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(theme.accentColor);
    if (m) {
      root.style.setProperty(
        '--accent-rgb',
        `${parseInt(m[1], 16)},${parseInt(m[2], 16)},${parseInt(m[3], 16)}`
      );
    }
  }, [theme.accentColor]);

  const hasMessages = messages.length > 0;
  // Orb dims subtly when chat is active — the graph IS the focus
  const orbOpacity = orbForceOpaque ? 1 : hasMessages ? 0.3 : 1;

  const handleOrbDoubleClick = useCallback(() => {
    setOrbForceOpaque(true);
    if (orbForceTimer.current) clearTimeout(orbForceTimer.current);
    orbForceTimer.current = setTimeout(() => setOrbForceOpaque(false), 8000);
  }, []);

  const sendMessage = useCallback((content: string) => {
    if (!content.trim() || isTyping) return;
    setOrbForceOpaque(false);

    const userMsg: Message = {
      id: `u-${Date.now()}`,
      role: 'user',
      content: content.trim(),
      timestamp: new Date(),
    };
    setMessages(prev => [...prev, userMsg]);
    setIsTyping(true);

    setTimeout(() => {
      const resp = AI_RESPONSES[Math.floor(Math.random() * AI_RESPONSES.length)];
      const assistantMsg: Message = {
        id: `a-${Date.now()}`,
        role: 'assistant',
        content: resp,
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, assistantMsg]);
      setIsTyping(false);
    }, 900 + Math.random() * 700);
  }, [isTyping]);

  const toggleVoice = useCallback(async () => {
    if (voiceMode) {
      streamRef.current?.getTracks().forEach(t => t.stop());
      streamRef.current = null;
      analyserRef.current = null;
      audioCtxRef.current?.close();
      audioCtxRef.current = null;
      setVoiceMode(false);
    } else {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        const ctx = new AudioContext();
        const source = ctx.createMediaStreamSource(stream);
        const analyser = ctx.createAnalyser();
        analyser.fftSize = 256;
        analyser.smoothingTimeConstant = 0.75;
        source.connect(analyser);
        streamRef.current = stream;
        audioCtxRef.current = ctx;
        analyserRef.current = analyser;
        setVoiceMode(true);
      } catch {
        alert('Microphone access is required for voice mode.');
      }
    }
  }, [voiceMode]);

  const statusText = voiceMode ? 'listening' : isTyping ? 'processing' : hasMessages ? 'active' : 'standby';

  return (
    <div className="jarvis-app">
      <TopBar darkMode={darkMode} onThemeToggle={() => setDarkMode(p => !p)} />

      <div className="jarvis-body">
        <Sidebar
          activeTab={activeTab}
          onTabChange={setActiveTab}
          darkMode={darkMode}
          onThemeToggle={() => setDarkMode(p => !p)}
          messageCount={messages.length}
        />

        <main className="jarvis-main">
          <div className="orb-stage">
            <OrbCanvas
              messages={messages}
              voiceMode={voiceMode}
              accentColor={theme.accentColor}
              opacity={orbOpacity}
              onDoubleClick={handleOrbDoubleClick}
              analyserRef={analyserRef}
              darkMode={darkMode}
            />

            <div className="orb-status">{statusText}</div>

            {voiceMode && (
              <div className="voice-pill">
                <div className="voice-dot" />
                <span className="voice-pill-text">voice active</span>
              </div>
            )}

            {hasMessages && <ChatArea messages={messages} />}

            {isTyping && (
              <div className="typing-indicator">
                <span className="typing-label">jarvis</span>
                <div className="typing-dots">
                  <div className="typing-dot" />
                  <div className="typing-dot" />
                  <div className="typing-dot" />
                </div>
              </div>
            )}

            {/* Zoom controls */}
            <div className="zoom-hint">
              <span className="zoom-label">scroll · zoom · drag</span>
              <div className="zoom-controls">
                <button
                  className="zoom-btn"
                  onClick={() => window.dispatchEvent(new CustomEvent('jarvis-zoom', { detail: -1 }))}
                  aria-label="Zoom out"
                >−</button>
                <button
                  className="zoom-btn"
                  onClick={() => window.dispatchEvent(new CustomEvent('jarvis-zoom', { detail: 1 }))}
                  aria-label="Zoom in"
                >+</button>
              </div>
            </div>
          </div>

          <InputBar
            input={input}
            onInputChange={setInput}
            onSend={() => { sendMessage(input); setInput(''); }}
            voiceMode={voiceMode}
            onVoiceToggle={toggleVoice}
            onThemeOpen={() => setThemeOpen(p => !p)}
            onPermissions={() => alert('Permissions: Microphone · File System · Web Search')}
            accentColor={theme.accentColor}
          />

          {themeOpen && (
            <ThemeCustomizer
              theme={theme}
              onChange={setTheme}
              onClose={() => setThemeOpen(false)}
            />
          )}
        </main>
      </div>
    </div>
  );
}
