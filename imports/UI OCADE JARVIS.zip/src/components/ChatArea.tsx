import { useEffect, useRef } from 'react';
import type { Message } from '../App';

interface Props {
  messages: Message[];
}

function fmt(d: Date): string {
  return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

export default function ChatArea({ messages }: Props) {
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages.length]);

  return (
    <div className="chat-overlay">
      <div className="chat-messages">
        {messages.map(msg => (
          <div key={msg.id} className={`message-row ${msg.role}`}>
            <div className={`msg-avatar ${msg.role}`}>
              {msg.role === 'user' ? 'U' : 'J'}
            </div>
            <div>
              <div className={`msg-bubble ${msg.role}`}>{msg.content}</div>
              <div className="msg-time">{fmt(msg.timestamp)}</div>
            </div>
          </div>
        ))}
        <div ref={endRef} />
      </div>
    </div>
  );
}
