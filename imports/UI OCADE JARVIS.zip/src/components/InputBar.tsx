import { useRef, useEffect } from 'react';

interface Props {
  input: string;
  onInputChange: (v: string) => void;
  onSend: () => void;
  voiceMode: boolean;
  onVoiceToggle: () => void;
  onThemeOpen: () => void;
  onPermissions: () => void;
  accentColor: string;
}

export default function InputBar({
  input, onInputChange, onSend, voiceMode, onVoiceToggle, onThemeOpen, onPermissions,
}: Props) {
  const taRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    const ta = taRef.current;
    if (!ta) return;
    ta.style.height = 'auto';
    ta.style.height = `${Math.min(ta.scrollHeight, 140)}px`;
  }, [input]);

  function onKey(e: React.KeyboardEvent<HTMLTextAreaElement>) {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      if (input.trim()) onSend();
    }
  }

  return (
    <div className="input-bar">
      <div className="input-bar-shell">
        {/* Attach */}
        <button className="icon-btn" title="Attach file" aria-label="Attach file">
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
            <path d="M21.44 11.05l-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48" />
          </svg>
        </button>

        <textarea
          ref={taRef}
          className="input-textarea"
          value={input}
          onChange={e => onInputChange(e.target.value)}
          onKeyDown={onKey}
          placeholder="Message Jarvis…"
          rows={1}
        />

        <div className="input-actions">
          <button
            className={`icon-btn${voiceMode ? ' voice-on' : ''}`}
            title={voiceMode ? 'Stop voice' : 'Voice mode'}
            onClick={onVoiceToggle}
            aria-label="Voice mode"
          >
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
              <path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z" />
              <path d="M19 10v2a7 7 0 0 1-14 0v-2" />
              <line x1="12" y1="19" x2="12" y2="23" />
              <line x1="8" y1="23" x2="16" y2="23" />
            </svg>
          </button>

          <button
            className="send-btn"
            disabled={!input.trim()}
            onClick={onSend}
            aria-label="Send"
          >
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
              <line x1="22" y1="2" x2="11" y2="13" />
              <polygon points="22 2 15 22 11 13 2 9 22 2" />
            </svg>
          </button>
        </div>
      </div>

      <div className="input-footer">
        <span className="input-hint">↵ send · ⇧↵ newline</span>
        <div className="input-footer-actions">
          <button className="footer-btn" onClick={onPermissions}>
            <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <rect x="3" y="11" width="18" height="11" rx="2" />
              <path d="M7 11V7a5 5 0 0 1 10 0v4" />
            </svg>
            Permissions
          </button>
          <button className="footer-btn accent" onClick={onThemeOpen}>
            <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <circle cx="12" cy="12" r="3" />
              <path d="M12 1v2M12 21v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M1 12h2M21 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42" />
            </svg>
            Orb color
          </button>
        </div>
      </div>
    </div>
  );
}
