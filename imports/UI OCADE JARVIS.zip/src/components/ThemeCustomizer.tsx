import type { ThemeConfig } from '../App';

interface Props {
  theme: ThemeConfig;
  onChange: (t: ThemeConfig) => void;
  onClose: () => void;
}

const ACCENT_PRESETS = [
  { color: '#00d4ff', label: 'Cyan' },
  { color: '#7ce0a8', label: 'Sage' },
  { color: '#b8a0f0', label: 'Lavender' },
  { color: '#f0a060', label: 'Amber' },
  { color: '#f07070', label: 'Coral' },
  { color: '#60a8f0', label: 'Sky' },
  { color: '#f0e060', label: 'Gold' },
  { color: '#ffffff', label: 'White' },
];

export default function ThemeCustomizer({ theme, onChange, onClose }: Props) {
  return (
    <div className="theme-panel">
      <div className="panel-header">
        <div className="panel-title">Orb Color</div>
        <button className="panel-close" onClick={onClose} aria-label="Close">
          <svg width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
            <line x1="18" y1="6" x2="6" y2="18" /><line x1="6" y1="6" x2="18" y2="18" />
          </svg>
        </button>
      </div>

      <div className="panel-label">Accent</div>
      <div className="swatch-row">
        {ACCENT_PRESETS.map(p => (
          <button
            key={p.color}
            className={`swatch${theme.accentColor === p.color ? ' sel' : ''}`}
            style={{ background: p.color }}
            title={p.label}
            onClick={() => onChange({ ...theme, accentColor: p.color })}
            aria-label={p.label}
          />
        ))}
      </div>

      <div className="custom-row">
        <div className="color-swatch-input" style={{ background: theme.accentColor }}>
          <input
            type="color"
            value={theme.accentColor}
            onChange={e => onChange({ ...theme, accentColor: e.target.value })}
            aria-label="Custom color"
          />
        </div>
        <span className="hex-label">{theme.accentColor.toUpperCase()} · custom</span>
      </div>

      <div className="orb-note">
        The orb glow and interactive node highlight use this color. The rest of the interface stays monochrome.
      </div>
    </div>
  );
}
