import { useRef, useEffect, useState, RefObject } from 'react';
import type { Message } from '../App';

interface Props {
  messages: Message[];
  voiceMode: boolean;
  accentColor: string;
  opacity: number;
  onDoubleClick: () => void;
  analyserRef: RefObject<AnalyserNode | null>;
  darkMode: boolean;
}

// ── Node model ────────────────────────────────────────────────
interface GNode {
  id: string;
  angle: number;       // base polar angle (radians)
  radius: number;      // base polar radius in canvas px
  z: number;           // depth-layer -1..1
  size: number;        // visual radius in px
  label: string;
  type: 'core' | 'memory' | 'user' | 'assistant';
  content?: string;
  timestamp?: string;
  opacity: number;
  // Physics
  vAngle: number;
  vRadius: number;
  attrX: number;       // cursor attraction offset x
  attrY: number;
  attrVX: number;
  attrVY: number;
}

interface GEdge {
  from: string;
  to: string;
  strength: number;    // 0-1
}

interface HoveredNode { node: GNode; sx: number; sy: number }

// ── Golden-angle spiral placement ────────────────────────────
const PHI_ANGLE = Math.PI * (3 - Math.sqrt(5));

function spiralPt(i: number, total: number, minR: number, maxR: number): [number, number] {
  const t = (i + 0.5) / total;
  const r = minR + Math.pow(t, 0.55) * (maxR - minR);
  const a = PHI_ANGLE * i;
  return [a, r];
}

function hexToRgb(hex: string): [number, number, number] {
  const m = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex.trim());
  return m ? [parseInt(m[1], 16), parseInt(m[2], 16), parseInt(m[3], 16)] : [0, 212, 255];
}

// ── Initial graph: 120 knowledge nodes in spiral ─────────────
function buildGraph(): { nodes: GNode[]; edges: GEdge[] } {
  const nodes: GNode[] = [];
  const edges: GEdge[] = [];

  // Core (not drawn as node — rendered as glass orb separately)
  nodes.push({
    id: 'core',
    angle: 0, radius: 0, z: 0,
    size: 0, label: 'Jarvis', type: 'core',
    opacity: 1, vAngle: 0, vRadius: 0, attrX: 0, attrY: 0, attrVX: 0, attrVY: 0,
  });

  const COUNT = 120;
  for (let i = 0; i < COUNT; i++) {
    const [a, r] = spiralPt(i, COUNT, 85, 520);
    const z = Math.sin(a * 1.7 + i * 0.3) * 0.6;
    const id = `k${i}`;

    // Variable node sizes: a few large "hub" nodes
    const isHub = i % 17 === 0;
    const isMid = i % 7 === 0;
    const sz = isHub ? 7 + Math.random() * 4 : isMid ? 3.5 + Math.random() * 2 : 2 + Math.random() * 1.8;

    nodes.push({
      id,
      angle: a, radius: r, z,
      size: sz,
      label: '',
      type: 'memory',
      opacity: 0,
      vAngle: 0, vRadius: 0,
      attrX: 0, attrY: 0, attrVX: 0, attrVY: 0,
    });

    // Every node connects back to core (radial thread)
    edges.push({ from: id, to: 'core', strength: 0.18 });
  }

  // Cluster cross-connections: connect nearby nodes by angle proximity
  const nodeList = nodes.filter(n => n.type === 'memory');
  for (let i = 0; i < nodeList.length; i++) {
    for (let j = i + 1; j < nodeList.length; j++) {
      const ai = nodeList[i].angle;
      const aj = nodeList[j].angle;
      const ri = nodeList[i].radius;
      const rj = nodeList[j].radius;
      // Angular proximity in same rough shell
      const dAngle = Math.abs(ai - aj);
      const dRadius = Math.abs(ri - rj);
      const minNorm = Math.min(dAngle, Math.PI * 2 - dAngle);
      if (minNorm < 0.28 && dRadius < 70 && Math.random() < 0.55) {
        edges.push({ from: nodeList[i].id, to: nodeList[j].id, strength: 0.38 + Math.random() * 0.25 });
      }
    }
  }

  return { nodes, edges };
}

const INITIAL = buildGraph();

// ── Component ─────────────────────────────────────────────────
export default function OrbCanvas({
  messages, voiceMode, accentColor, opacity, onDoubleClick, analyserRef, darkMode,
}: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const animRef = useRef<number>(0);

  // Graph state (mutated in-place for performance)
  const nodesRef = useRef<GNode[]>(INITIAL.nodes.map(n => ({ ...n })));
  const edgesRef = useRef<GEdge[]>([...INITIAL.edges]);
  const prevMsgCountRef = useRef(0);

  // Camera
  const camRef = useRef({ zoom: 1, tz: 1, px: 0, py: 0, tpx: 0, tpy: 0 });

  // Animation state
  const spinRef = useRef(0);
  const timeRef = useRef(0);

  // Input state
  const curRef = useRef({ x: -9999, y: -9999 });
  const dragRef = useRef({ active: false, mx: 0, my: 0, px: 0, py: 0 });

  // Dynamic refs
  const accentRef = useRef(accentColor);
  useEffect(() => { accentRef.current = accentColor; }, [accentColor]);
  const darkRef = useRef(darkMode);
  useEffect(() => { darkRef.current = darkMode; }, [darkMode]);
  const voiceRef = useRef(voiceMode);
  useEffect(() => { voiceRef.current = voiceMode; }, [voiceMode]);

  // Tooltip (React state for re-render)
  const [hovered, setHovered] = useState<HoveredNode | null>(null);
  const hovIdRef = useRef<string | null>(null);

  // ── Sync messages → new graph nodes ──────────────────────────
  useEffect(() => {
    const prev = prevMsgCountRef.current;
    if (messages.length <= prev) return;

    for (let i = prev; i < messages.length; i++) {
      const msg = messages[i];
      const isUser = msg.role === 'user';
      // Place new nodes at increasing radius with distinct angle
      const baseAngle = PHI_ANGLE * (INITIAL.nodes.length + i) + (isUser ? 0 : Math.PI * 0.15);
      const baseRadius = 160 + Math.sqrt(i + 1) * 65;

      const id = msg.id;
      const newNode: GNode = {
        id,
        angle: baseAngle,
        radius: Math.min(baseRadius, 490),
        z: Math.random() * 1.2 - 0.6,
        size: isUser ? 8 : 6.5,
        label: msg.content.slice(0, 28) + (msg.content.length > 28 ? '…' : ''),
        type: isUser ? 'user' : 'assistant',
        content: msg.content,
        timestamp: msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        opacity: 0,
        vAngle: 0, vRadius: 0, attrX: 0, attrY: 0, attrVX: 0, attrVY: 0,
      };

      nodesRef.current.push(newNode);

      // Radial + peer connections
      edgesRef.current.push({ from: id, to: 'core', strength: 0.5 });
      if (i > prev && messages[i - 1]) {
        edgesRef.current.push({ from: id, to: messages[i - 1].id, strength: 0.7 });
      }
      // Connect to a nearby knowledge node for integration
      const knowledgeNodes = nodesRef.current.filter(n => n.type === 'memory');
      if (knowledgeNodes.length > 0) {
        const nn = knowledgeNodes[Math.floor(Math.random() * Math.min(12, knowledgeNodes.length))];
        edgesRef.current.push({ from: id, to: nn.id, strength: 0.35 });
      }
    }

    prevMsgCountRef.current = messages.length;
  }, [messages]);

  // ── Pointer + scroll events ───────────────────────────────────
  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;

    const onMove = (e: MouseEvent) => {
      const r = el.getBoundingClientRect();
      curRef.current = { x: e.clientX - r.left, y: e.clientY - r.top };
      if (dragRef.current.active && camRef.current.zoom > 1.05) {
        const dx = e.clientX - dragRef.current.mx;
        const dy = e.clientY - dragRef.current.my;
        camRef.current.tpx = dragRef.current.px + dx;
        camRef.current.tpy = dragRef.current.py + dy;
      }
    };

    const onDown = (e: MouseEvent) => {
      dragRef.current = { active: true, mx: e.clientX, my: e.clientY, px: camRef.current.tpx, py: camRef.current.tpy };
    };

    const onUp = () => { dragRef.current.active = false; };

    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      const d = e.deltaY < 0 ? 1.14 : 0.88;
      const cam = camRef.current;
      const next = Math.max(0.3, Math.min(7, cam.tz * d));
      const r = el.getBoundingClientRect();
      const mx = e.clientX - r.left - el.offsetWidth / 2;
      const my = e.clientY - r.top - el.offsetHeight / 2;
      const s = next / cam.tz;
      cam.tpx = mx - (mx - cam.tpx) * s;
      cam.tpy = my - (my - cam.tpy) * s;
      cam.tz = next;
    };

    const onLeave = () => { curRef.current = { x: -9999, y: -9999 }; };

    const onZoomBtn = (e: Event) => {
      const dir = (e as CustomEvent).detail as number;
      const cam = camRef.current;
      cam.tz = Math.max(0.3, Math.min(7, cam.tz * (dir > 0 ? 1.25 : 0.8)));
    };

    el.addEventListener('mousemove', onMove);
    el.addEventListener('mousedown', onDown);
    window.addEventListener('mouseup', onUp);
    el.addEventListener('wheel', onWheel, { passive: false });
    el.addEventListener('mouseleave', onLeave);
    window.addEventListener('jarvis-zoom', onZoomBtn);

    return () => {
      el.removeEventListener('mousemove', onMove);
      el.removeEventListener('mousedown', onDown);
      window.removeEventListener('mouseup', onUp);
      el.removeEventListener('wheel', onWheel);
      el.removeEventListener('mouseleave', onLeave);
      window.removeEventListener('jarvis-zoom', onZoomBtn);
    };
  }, []);

  // ── Animation loop ────────────────────────────────────────────
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d')!;

    function resize() {
      const c = canvasRef.current!;
      c.width = c.offsetWidth * devicePixelRatio;
      c.height = c.offsetHeight * devicePixelRatio;
    }
    resize();
    const ro = new ResizeObserver(resize);
    ro.observe(canvas);

    function getAmp(): number {
      const an = analyserRef.current;
      if (!an || !voiceRef.current) return 0;
      const d = new Uint8Array(an.frequencyBinCount);
      an.getByteFrequencyData(d);
      let s = 0;
      for (let i = 0; i < d.length; i++) s += d[i] * (i < d.length / 4 ? 2 : 1);
      return Math.min(2, (s / (d.length * 1.5)) / 128);
    }

    function draw() {
      const c = canvasRef.current;
      if (!c) return;
      const W = c.width, H = c.height, dpr = devicePixelRatio;
      const CX = W / 2, CY = H / 2;

      ctx.clearRect(0, 0, W, H);

      // Smooth camera
      const cam = camRef.current;
      cam.zoom += (cam.tz - cam.zoom) * 0.09;
      cam.px += (cam.tpx - cam.px) * 0.09;
      cam.py += (cam.tpy - cam.py) * 0.09;
      const { zoom, px, py } = cam;
      const DPR_PX = px * dpr, DPR_PY = py * dpr;

      const amp = getAmp();
      const isVoice = voiceRef.current;
      const isDark = darkRef.current;
      const accent = accentRef.current;
      const [ar, ag, ab] = hexToRgb(accent);

      // Slow 3D spin (Y-axis rotation)
      const rotSpeed = isVoice ? 0.0025 + amp * 0.008 : 0.001;
      spinRef.current += rotSpeed;
      timeRef.current += 0.016;
      const spin = spinRef.current;
      const cosS = Math.cos(spin);
      const sinS = Math.sin(spin);
      // Small X-tilt for depth
      const tiltX = Math.sin(timeRef.current * 0.08) * 0.08;
      const cosTX = Math.cos(tiltX), sinTX = Math.sin(tiltX);

      // Node fill color
      const NR = isDark ? 255 : 18, NG = isDark ? 255 : 18, NB = isDark ? 255 : 18;

      // Project a node's polar+z to screen coords
      function projectNode(n: GNode): { sx: number; sy: number; depthScale: number } {
        const voicePulse = isVoice ? 1 + amp * 0.18 : 1;
        const r = n.radius * zoom * voicePulse;
        const a = n.angle;

        // Polar to Cartesian
        const baseX = Math.cos(a) * r;
        const baseY = Math.sin(a) * r * 0.88;  // slight Y compression for 3D feel
        const baseZ = n.z * r * 0.35;

        // Y-axis rotation (spin)
        const rx = baseX * cosS + baseZ * sinS;
        const rz = -baseX * sinS + baseZ * cosS;
        // X-axis tilt
        const ry = baseY * cosTX - rz * sinTX;
        const rz2 = baseY * sinTX + rz * cosTX;

        // Perspective
        const FOCAL = Math.max(W, H) * 0.85;
        const depth = FOCAL + rz2;
        const ps = FOCAL / Math.max(depth, 0.1);

        return {
          sx: CX + DPR_PX + (rx * ps + n.attrX * dpr),
          sy: CY + DPR_PY + (ry * ps + n.attrY * dpr),
          depthScale: Math.max(0.3, Math.min(1.6, ps / 1)),
        };
      }

      // Project core for orb center
      const orbCenter = { sx: CX + DPR_PX, sy: CY + DPR_PY };
      const ORB_R = Math.min(W, H) * 0.065;  // small orb ~6.5% of min dim

      // ── Physics: fade-in, cursor attraction ──────────────────
      const cx_screen = curRef.current.x;
      const cy_screen = curRef.current.y;
      const ATTRACT_R = 160;
      const ATTRACT_F = 22;

      for (const n of nodesRef.current) {
        if (n.type === 'core') continue;
        if (n.opacity < 1) n.opacity = Math.min(1, n.opacity + 0.008);

        // Idle micro-drift in polar space
        const drift = 0.0004;
        n.vAngle += (Math.sin(timeRef.current * 0.4 + n.angle * 3) * drift);
        n.vRadius += (Math.cos(timeRef.current * 0.3 + n.radius * 0.01) * 0.12);
        n.vAngle *= 0.94;
        n.vRadius *= 0.92;
        n.angle += n.vAngle;
        n.radius += n.vRadius;

        // Cursor attraction in screen space
        const { sx, sy } = projectNode(n);
        const dx = (cx_screen * dpr) - sx;
        const dy = (cy_screen * dpr) - sy;
        const dist = Math.sqrt(dx * dx + dy * dy) / dpr;

        if (dist < ATTRACT_R && cx_screen > -100) {
          const pull = (1 - dist / ATTRACT_R) * ATTRACT_F;
          n.attrVX += dx / Math.max(dist * dpr, 1) * pull;
          n.attrVY += dy / Math.max(dist * dpr, 1) * pull;
        }

        n.attrVX *= 0.82;
        n.attrVY *= 0.82;
        n.attrX += n.attrVX;
        n.attrY += n.attrVY;
        // Spring back
        n.attrX *= 0.93;
        n.attrY *= 0.93;
      }

      // ── Build projected positions ─────────────────────────────
      const projMap = new Map<string, { sx: number; sy: number; depthScale: number }>();
      projMap.set('core', { sx: orbCenter.sx, sy: orbCenter.sy, depthScale: 1 });
      for (const n of nodesRef.current) {
        if (n.type === 'core') continue;
        projMap.set(n.id, projectNode(n));
      }

      // ── Find hovered node ─────────────────────────────────────
      let closestId: string | null = null;
      let closestDist = Infinity;
      let closestSX = 0, closestSY = 0;

      for (const n of nodesRef.current) {
        if (n.type === 'core' || n.size < 1) continue;
        const p = projMap.get(n.id);
        if (!p) continue;
        const dx = p.sx / dpr - cx_screen;
        const dy = p.sy / dpr - cy_screen;
        const d = Math.sqrt(dx * dx + dy * dy);
        const hitR = (n.size * Math.max(0.8, p.depthScale) + 12);
        if (d < hitR && d < closestDist) {
          closestDist = d;
          closestId = n.id;
          closestSX = p.sx / dpr;
          closestSY = p.sy / dpr;
        }
      }

      if (closestId !== hovIdRef.current) {
        hovIdRef.current = closestId;
        if (closestId) {
          const hn = nodesRef.current.find(n => n.id === closestId);
          if (hn?.content) setHovered({ node: hn, sx: closestSX, sy: closestSY });
          else setHovered(null);
        } else {
          setHovered(null);
        }
      }

      // ── Draw edges ─────────────────────────────────────────────
      for (const e of edgesRef.current) {
        const pA = projMap.get(e.from);
        const pB = projMap.get(e.to);
        if (!pA || !pB) continue;

        const isHighlit = e.from === closestId || e.to === closestId;
        const toCore = e.to === 'core' || e.from === 'core';

        let alpha: number;
        if (isHighlit) {
          alpha = isDark ? 0.75 : 0.6;
        } else if (toCore) {
          // Radial threads from orb: gradient effect
          alpha = isDark ? e.strength * 0.22 : e.strength * 0.16;
        } else {
          alpha = isDark ? e.strength * 0.38 : e.strength * 0.28;
        }

        const lw = isHighlit ? 1.0 / dpr : toCore ? 0.4 / dpr : 0.65 / dpr;

        if (toCore) {
          // Gradient line: faint at orb end, slightly brighter at node end
          const grad = ctx.createLinearGradient(pA.sx, pA.sy, pB.sx, pB.sy);
          const nearCore = e.from === 'core' ? 0 : 1;
          grad.addColorStop(nearCore, `rgba(${NR},${NG},${NB},${alpha * 0.15})`);
          grad.addColorStop(1 - nearCore, `rgba(${NR},${NG},${NB},${alpha})`);
          ctx.beginPath();
          ctx.strokeStyle = grad;
          ctx.lineWidth = lw;
          ctx.moveTo(pA.sx, pA.sy);
          ctx.lineTo(pB.sx, pB.sy);
          ctx.stroke();
        } else {
          ctx.beginPath();
          ctx.strokeStyle = `rgba(${NR},${NG},${NB},${alpha})`;
          ctx.lineWidth = lw;
          ctx.moveTo(pA.sx, pA.sy);
          ctx.lineTo(pB.sx, pB.sy);
          ctx.stroke();
        }
      }

      // ── Draw nodes (depth sorted) ─────────────────────────────
      const sortedNodes = [...nodesRef.current]
        .filter(n => n.type !== 'core' && n.size > 0)
        .sort((a, b) => (projMap.get(a.id)?.depthScale ?? 1) - (projMap.get(b.id)?.depthScale ?? 1));

      for (const n of sortedNodes) {
        const p = projMap.get(n.id);
        if (!p) continue;

        const isHov = n.id === closestId;
        const ds = Math.max(0.5, Math.min(1.5, p.depthScale));
        const finalOpacity = n.opacity * (0.5 + ds * 0.5);
        const nodeR = (n.size * ds) / dpr;

        if (isHov) {
          // Glow ring (accent)
          const glowR = nodeR * 3.5;
          const grd = ctx.createRadialGradient(p.sx / dpr, p.sy / dpr, 0, p.sx / dpr, p.sy / dpr, glowR);
          grd.addColorStop(0, `rgba(${ar},${ag},${ab},${0.3 * finalOpacity})`);
          grd.addColorStop(0.5, `rgba(${ar},${ag},${ab},${0.08 * finalOpacity})`);
          grd.addColorStop(1, `rgba(${ar},${ag},${ab},0)`);
          ctx.beginPath();
          ctx.arc(p.sx / dpr, p.sy / dpr, glowR, 0, Math.PI * 2);
          ctx.fillStyle = grd;
          ctx.fill();

          ctx.beginPath();
          ctx.arc(p.sx / dpr, p.sy / dpr, nodeR, 0, Math.PI * 2);
          ctx.fillStyle = `rgba(${ar},${ag},${ab},${finalOpacity})`;
          ctx.fill();
        } else {
          // Soft glow for larger hub nodes
          if (n.size > 6) {
            const hGrd = ctx.createRadialGradient(p.sx / dpr, p.sy / dpr, 0, p.sx / dpr, p.sy / dpr, nodeR * 2.5);
            hGrd.addColorStop(0, `rgba(${NR},${NG},${NB},${0.12 * finalOpacity})`);
            hGrd.addColorStop(1, 'rgba(0,0,0,0)');
            ctx.beginPath();
            ctx.arc(p.sx / dpr, p.sy / dpr, nodeR * 2.5, 0, Math.PI * 2);
            ctx.fillStyle = hGrd;
            ctx.fill();
          }

          ctx.beginPath();
          ctx.arc(p.sx / dpr, p.sy / dpr, nodeR, 0, Math.PI * 2);
          ctx.fillStyle = `rgba(${NR},${NG},${NB},${finalOpacity})`;
          ctx.fill();
        }
      }

      // ── Labels at high zoom ───────────────────────────────────
      if (zoom > 2) {
        const la = Math.min(1, (zoom - 2) / 0.8);
        ctx.font = `${10.5 / dpr}px Inter, sans-serif`;
        for (const n of sortedNodes) {
          if (!n.label || n.type === 'memory') continue;
          const p = projMap.get(n.id);
          if (!p) continue;
          ctx.fillStyle = `rgba(${NR},${NG},${NB},${n.opacity * la * 0.65})`;
          ctx.textAlign = 'left';
          ctx.fillText(n.label, p.sx / dpr + (n.size * p.depthScale) / dpr + 5, p.sy / dpr + 4);
        }
      }

      // ── Central glass orb ─────────────────────────────────────
      const ox = orbCenter.sx / dpr;
      const oy = orbCenter.sy / dpr;
      const orb = ORB_R / dpr;
      const voiceBulge = isVoice ? 1 + amp * 0.15 : 1 + Math.sin(timeRef.current * 0.5) * 0.012;
      const oR = orb * voiceBulge;

      // Accent glow behind orb
      const glowAmp = 0.1 + amp * 0.25;
      const outerG = ctx.createRadialGradient(ox, oy, oR * 0.3, ox, oy, oR * 3.5);
      outerG.addColorStop(0, `rgba(${ar},${ag},${ab},${glowAmp})`);
      outerG.addColorStop(0.5, `rgba(${ar},${ag},${ab},${glowAmp * 0.25})`);
      outerG.addColorStop(1, `rgba(${ar},${ag},${ab},0)`);
      ctx.beginPath();
      ctx.arc(ox, oy, oR * 3.5, 0, Math.PI * 2);
      ctx.fillStyle = outerG;
      ctx.fill();

      // Glass body — dark sphere with radial gradient
      const glassFill = ctx.createRadialGradient(
        ox - oR * 0.3, oy - oR * 0.3, oR * 0.04,
        ox, oy, oR
      );
      if (isDark) {
        glassFill.addColorStop(0, 'rgba(95,95,100,0.62)');
        glassFill.addColorStop(0.4, 'rgba(35,35,40,0.72)');
        glassFill.addColorStop(0.85, 'rgba(10,10,14,0.88)');
        glassFill.addColorStop(1, 'rgba(5,5,8,0.96)');
      } else {
        glassFill.addColorStop(0, 'rgba(240,240,245,0.88)');
        glassFill.addColorStop(0.4, 'rgba(200,200,210,0.82)');
        glassFill.addColorStop(1, 'rgba(150,150,165,0.92)');
      }
      ctx.beginPath();
      ctx.arc(ox, oy, oR, 0, Math.PI * 2);
      ctx.fillStyle = glassFill;
      ctx.fill();

      // Primary specular highlight
      const spec = ctx.createRadialGradient(
        ox - oR * 0.35, oy - oR * 0.35, 0,
        ox - oR * 0.2, oy - oR * 0.2, oR * 0.6
      );
      spec.addColorStop(0, `rgba(255,255,255,${isDark ? 0.28 : 0.55})`);
      spec.addColorStop(0.5, `rgba(255,255,255,${isDark ? 0.06 : 0.15})`);
      spec.addColorStop(1, 'rgba(255,255,255,0)');
      ctx.beginPath();
      ctx.arc(ox, oy, oR, 0, Math.PI * 2);
      ctx.fillStyle = spec;
      ctx.fill();

      // Secondary bottom-right fill (refracted light)
      const spec2 = ctx.createRadialGradient(ox + oR * 0.4, oy + oR * 0.4, 0, ox + oR * 0.2, oy + oR * 0.2, oR * 0.45);
      spec2.addColorStop(0, `rgba(${ar},${ag},${ab},${isDark ? 0.07 : 0.04})`);
      spec2.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.beginPath();
      ctx.arc(ox, oy, oR, 0, Math.PI * 2);
      ctx.fillStyle = spec2;
      ctx.fill();

      // Rim
      ctx.beginPath();
      ctx.arc(ox, oy, oR, 0, Math.PI * 2);
      ctx.strokeStyle = `rgba(${isDark ? 255 : 80},${isDark ? 255 : 80},${isDark ? 255 : 80},${isDark ? 0.1 : 0.2})`;
      ctx.lineWidth = 0.7 / dpr;
      ctx.stroke();

      animRef.current = requestAnimationFrame(draw);
    }

    animRef.current = requestAnimationFrame(draw);
    return () => {
      cancelAnimationFrame(animRef.current);
      ro.disconnect();
    };
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // ── Tooltip placement ─────────────────────────────────────────
  function tooltipStyle(sx: number, sy: number): React.CSSProperties {
    const el = containerRef.current;
    if (!el) return { left: sx + 16, top: sy - 10 };
    const W = el.offsetWidth, H = el.offsetHeight;
    const PW = 252, PH = 180;
    return {
      left: sx + 18 + PW > W ? sx - PW - 14 : sx + 18,
      top: sy + PH > H ? Math.max(8, sy - PH + 20) : Math.max(8, sy - 12),
    };
  }

  return (
    <div ref={containerRef} style={{ position: 'absolute', inset: 0 }} onDoubleClick={onDoubleClick}>
      <canvas ref={canvasRef} className="orb-canvas" style={{ opacity }} />

      {hovered?.node.content && (
        <div className="graph-tooltip" style={tooltipStyle(hovered.sx, hovered.sy)}>
          <div className="tooltip-type">{hovered.node.type === 'user' ? 'you' : 'jarvis'}</div>
          <div className="tooltip-content">{hovered.node.content}</div>
          {hovered.node.timestamp && (
            <div className="tooltip-meta">
              <div className="tooltip-dot" />
              {hovered.node.timestamp}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
