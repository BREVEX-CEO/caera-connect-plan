---
name: Neural Obsidian
colors:
  surface: '#131315'
  surface-dim: '#131315'
  surface-bright: '#39393b'
  surface-container-lowest: '#0e0e10'
  surface-container-low: '#1c1b1e'
  surface-container: '#201f22'
  surface-container-high: '#2a2a2c'
  surface-container-highest: '#353437'
  on-surface: '#e5e1e4'
  on-surface-variant: '#e8bcba'
  inverse-surface: '#e5e1e4'
  inverse-on-surface: '#313032'
  outline: '#af8785'
  outline-variant: '#5e3f3d'
  surface-tint: '#ffb3b0'
  primary: '#ffb3b0'
  on-primary: '#680010'
  primary-container: '#ff5359'
  on-primary-container: '#5b000d'
  inverse-primary: '#bf0027'
  secondary: '#c6c6c7'
  on-secondary: '#2f3131'
  secondary-container: '#454747'
  on-secondary-container: '#b4b5b5'
  tertiary: '#ffb4ac'
  on-tertiary: '#690007'
  tertiary-container: '#f55e55'
  on-tertiary-container: '#5c0005'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffdad8'
  primary-fixed-dim: '#ffb3b0'
  on-primary-fixed: '#410007'
  on-primary-fixed-variant: '#92001b'
  secondary-fixed: '#e2e2e2'
  secondary-fixed-dim: '#c6c6c7'
  on-secondary-fixed: '#1a1c1c'
  on-secondary-fixed-variant: '#454747'
  tertiary-fixed: '#ffdad6'
  tertiary-fixed-dim: '#ffb4ac'
  on-tertiary-fixed: '#410002'
  on-tertiary-fixed-variant: '#8e1214'
  background: '#131315'
  on-background: '#e5e1e4'
  surface-variant: '#353437'
typography:
  headline-xl:
    fontFamily: Space Grotesk
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
  headline-xl-mobile:
    fontFamily: Space Grotesk
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
  headline-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Geist
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
  body-md:
    fontFamily: Geist
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
  body-sm:
    fontFamily: Geist
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
  label-lg:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '600'
    lineHeight: 14px
spacing:
  gutter: 1.25rem
  margin: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system channels an advanced command interface aesthetic, pairing high-density technical utility with cinematic intensity. It is engineered for next-generation AI control consoles, neural monitoring dashboards, and real-time telemetry systems. 

The emotional signature is razor-sharp, authoritative, and frictionless. The interface maintains a pitch-black abyss punctuated by hyper-focused laser lines, precise typographic hierarchy, and luminous crimson signatures. The styling draws heavily from modern technical minimalism and brutalist telemetry:
- **Surface Dominance:** Void-black foundations with razor-thin structural divisions.
- **Dynamic Energy:** Precision crimson energy indicators, glowing neural links, and ambient status orbs.
- **Technical Rigor:** Uncompromising typographic calibration with monospace metadata readouts for immediate data extraction.

## Colors

The palette operates on absolute contrast principles, maximizing legibility in low-light environments while delivering punchy visual hierarchy.

- **Primary (`#ff1a3c`):** High-energy neon crimson reserved for active telemetry nodes, laser crosshairs, critical overrides, active toggles, and pulsating visualizer states.
- **Secondary (`#ffffff`):** Stark optical white for primary data values, key headings, and sharp focal markers.
- **Tertiary (`#991b1b`):** Subdued deep scarlet for background traces, boundary glows, deactivated danger barriers, and structural neural lines.
- **Neutral Core:** Built around pitch abyss tones (`#000000` base, `#08080a` card container, `#111114` elevated HUD tiles) with `#27272a` boundary borders and `#a1a1aa` muted technical labels.

## Typography

The typographic system utilizes a specialized tri-font hierarchy:
1. **Space Grotesk** drives headlines and display readouts, lending architectural presence and futuristic geometry.
2. **Geist** delivers crisp, neutral parsing for long-form synthetic outputs, dialog threads, and body copy.
3. **JetBrains Mono** governs the command console layer, handling telemetry streams, status badges, coordinate systems, and numeric indicators.

All labels and telemetry values must use uppercase styling (`text-transform: uppercase`) paired with slight positive letter tracking (+0.05em to +0.1em) to mimic hardware console readouts.

## Layout & Spacing

The architecture operates on a 12-column modular fluid grid designed for low visual bloat and maximum data real estate:
- **Canvas Margins:** Fixed at 2rem (32px) on desktop viewpoints, reducing to 1rem (16px) on mobile viewports.
- **Gutters:** 1.25rem (20px) to balance structural modularity with compact multi-panel displays.
- **Responsive Layout:**
  - **Desktop (1200px+):** 12 columns with persistent telemetry sidebar and multi-pane neural feed.
  - **Tablet (768px - 1199px):** 8 columns with collapsible secondary monitor drawer.
  - **Mobile (<768px):** 4 columns; auxiliary monitors convert to bottom sheets, prioritizing the central AI node and prompt input.

## Elevation & Depth

This system avoids traditional diffuse drop shadows. Depth is achieved via **tonal stacking**, **ultra-sharp border delineation**, and **directional crimson photon glows**:

- **Layer 0 (Canvas):** Pure `#000000`.
- **Layer 1 (Modular Panels):** `#08080a` with a 1px border of `#1a1a1f`.
- **Layer 2 (Interactive Modules):** `#111114` with a 1px border of `#27272a`.
- **Active / Focused Glow:** When an element becomes active (e.g., active input or engaged neural orb), replace traditional elevation shadows with an intense crimson photon halo: `box-shadow: 0 0 20px -2px rgba(255, 26, 60, 0.4), 0 0 1px 1px #ff1a3c`.
- **Frosted Overlays:** HUD modals utilize subtle backdrops (`rgba(8, 8, 10, 0.85)` with `backdrop-filter: blur(12px)`), framed with high-contrast border ticks at the corners.

## Shapes

The interface embraces a razor-sharp, zero-radius design language (`roundedness: 0`). 

Corners are pure 90-degree cuts or 45-degree chamfers, reinforcing the tactile sensation of tactical hardware interfaces and terminal consoles. Avoid rounded corners entirely, preserving strict geometric discipline across every button, card, modal, and badge.

## Components

### Buttons & Triggers
- **Primary Command Button:** Flat `#ff1a3c` background with `#000000` text, bold `JetBrains Mono` uppercase typography, zero radius, and edge micro-tick styling. On hover: invert to `#ffffff` background with crimson box-shadow emission.
- **Secondary / HUD Button:** Pure `#000000` background, 1px `#27272a` border, `#ffffff` text. On hover: border shifts to `#ff1a3c` with `#ff1a3c` text color shift.

### Chips & Badges
- Strict technical format (`[ STATUS: ONLINE ]` or `[ 44.1 KHZ ]`).
- `#08080a` background with 1px hairline border in `#ff1a3c` (for active/critical) or `#27272a` (for neutral).
- Accompanied by a 6px square crimson LED indicator that pulses when telemetry is active.

### Inputs & Terminal Console
- Single-line or multi-line dark canvas `#050507` encased in a 1px `#27272a` perimeter.
- Focus state: Instant transition to `#ff1a3c` border, accompanied by a blinking crimson terminal block cursor. Prefix inputs with monospace prompt tokens (`>_`).

### Neural Cards & Panels
- Constructed from `#08080a` with a sharp 1px `#18181b` boundary.
- Header bars feature technical panel numbering (e.g., `SEC-04 // TELEMETRY`) set in `JetBrains Mono` sm/muted.
- Upper-right and bottom-left panel corners feature subtle 4px L-bracket corner tick marks.

### Checkboxes & Binary Selectors
- Sharp square checkboxes (16x16px), 1px `#27272a` stroke. When toggled, the interior fills with solid `#ff1a3c` featuring an inverted black crosshair mark instead of a standard checkmark.

### Telemetry Stream & Neural Orb (Custom Components)
- **Neural Orb Container:** Centered spherical vector canvas emitting radial crimson luminescence (`rgba(255, 26, 60, 0.15)` to transparent) with real-time audio/data reaction waves.
- **Data HUD Rail:** Vertical strip pinned to panel edges displaying dynamic coordinate meters, CPU load traces, and memory allocation counters in `JetBrains Mono` label-sm.